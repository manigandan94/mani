package StepDefAma;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef123 {
	
	static WebDriver obj;
	@Given("^i have amazon url$")
	public void url() {
		
System.setProperty("webdriver.chrome.driver","C:\\Users\\RM MANI\\eclipse-workspace\\Orangehrm\\Drivers\\chromedriver.exe");
		
		 obj=new ChromeDriver();
		
		obj.get("https://www.amazon.in/");
		
		obj.manage().window().maximize();

	}
	@When("^type product name$")
	public void product() {
	
		obj.findElement(By.id("twotabsearchtextbox")).sendKeys("iphone 6s mobile phone");
		
	}
	@Then("^Select product$") 
	public void select() {
		obj.findElement(By.className("nav-input")).click();
		obj.findElement(By.linkText("Baseus")).click();
		obj.close();
	}

}
