package StepDef1;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Mercuryregister {

	 static WebDriver driver;
	 public void screenshot(String s1)
	 {
		 TakesScreenshot scrn= ((TakesScreenshot)driver);
		 File scrfile= scrn.getScreenshotAs(OutputType.FILE);
		 File destpath=new File("C:\\Users\\RM MANI\\Downloads\\SUMMERCAMP-Online Training-Maveric\\Selenium\\Scrnshot\\"+s1+".jpg");
		 try {
			FileUtils.copyFile(scrfile, destpath);
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	 
	 }
	 @Given("^i have url$")
	 public void URL()
		{
		    driver=new ChromeDriver();		
	driver.manage().deleteAllCookies();
	
	driver.get("http://demo.guru99.com/test/newtours/");
	driver.manage().window().maximize();
	screenshot("launch-mercury");
	String str= "Welcome: Mercury Tours";
	String abc= driver.getTitle();
	if(str.equals(abc)) {
		System.out.println(driver.getTitle());
       System.out.println("Title successful");
	}
	else
	{
		System.out.println("failed");
	}
		}
	 
	@When("^Click Register Tab$")
	public void register()
	{
	driver.findElement(By.linkText("REGISTER")).click();
	}
	
	@And("^enter the details$")
	public void details() throws Exception {
		
		
	WebElement s2=driver.findElement(By.name("firstName"));
		s2.sendKeys("Qwerty");
			s2.getAttribute("value");
	System.out.println(s2);
	
	WebElement s3=driver.findElement(By.name("lastName"));
	s3.sendKeys("Sweet"); 
	s3.getAttribute("value");
	System.out.println(s2);
	
	WebElement s4=driver.findElement(By.name("phone"));
	s4.sendKeys("9876543210");
	s4.getAttribute("value");
	System.out.println(s2);
	
	WebElement s5=driver.findElement(By.id("userName"));
			s5.sendKeys("Qwerty@gmail.com");
			s4.getAttribute("value");
			System.out.println(s2);
	
	WebElement s6=	driver.findElement(By.name("address1"));
	s6.sendKeys("bharathi nagar");
	s6.getAttribute("value");
	System.out.println(s6);
	
	WebElement s7=driver.findElement(By.name("city"));
	s7.sendKeys("Chennai");
	s7.getAttribute("value");
	System.out.println(s7);
	
	WebElement s8=driver.findElement(By.name("state"));
	s8.sendKeys("TN");
	s8.getAttribute("value");
	System.out.println(s8);
	
	WebElement s9=driver.findElement(By.name("postalCode"));
	s9.sendKeys("6001234");
	s9.getAttribute("value");
	System.out.println(s9);
	
	WebElement s10=driver.findElement(By.name("state"));
	s10.sendKeys("TN");
	s10.getAttribute("value");
	System.out.println(s10);
	
	Select cont =new Select(driver.findElement(By.name("country")));
	cont.selectByVisibleText("AUSTRALIA");
	//cont.selectByIndex(6);
	Thread.sleep(3000);
	screenshot("Register page-mercury");

	WebElement UN= driver.findElement(By.id("email"));
	UN.sendKeys("Hellomercury@gmail.com");
	String strExp = "Hellomercury@gmail.com";
   		
	WebElement s11=driver.findElement(By.name("password"));
	s11.sendKeys("Yellowteam");
	s11.getAttribute("value");
	System.out.println(s11);
	
	WebElement s12=driver.findElement(By.name("confirmPassword"));
	s12.sendKeys("Yellowteam");
	s12.getAttribute("value");
	System.out.println(s12);
	
	screenshot("Register page1-mercury");
	
	WebElement s13=driver.findElement(By.name("submit"));
	s13.click();
	String s1=driver.findElement(By.xpath("//p[3]/font/b")).getText();
	Thread.sleep(2000);
	
	
if(s1.contains(strExp)){
    System.out.println("String Matches:Pass");
}
    else {
        System.out.println("String Matches:Fail");
    }		
	}
	
@When("^enter (.*?) and (.*?)$")
public void login(String s1,String s2)
{
	try {
		driver.findElement(By.name("userName")).sendKeys(s1);
		driver.findElement(By.name("password")).sendKeys(s2);
		screenshot("login-mercury");
		driver.findElement(By.name("submit")).click();
	} catch (Exception e) {
		
		System.out.println("no such element");
	}
}


@Then("^not able to login application$")
public void fail()
{
	
	String str1=driver.findElement(By.xpath("//span")).getText();
	System.out.println(str1);
	screenshot("signup again-mercury");
	String str2="Enter your userName and password correct";
	if(str2.equals(str1))
	{
		System.out.println("Assertion passed");
	}
	else
		{
		System.out.println("Assertion failed");
		}
	
	driver.quit();
}
	}

