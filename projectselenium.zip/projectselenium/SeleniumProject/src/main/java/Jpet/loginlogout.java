package Jpet;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class loginlogout
{
public static void main(String[] args) {
		
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\RM MANI\\eclipse-workspace\\Orangehrm\\Drivers\\chromedriver.exe");
		
		WebDriver driver= new ChromeDriver();
		
		driver.manage().deleteAllCookies();
		driver.get("https://petstore.octoperf.com/actions/Catalog.action");
		
		driver.manage().window().maximize();		
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		
		driver.findElement(By.linkText("Sign In")).click();
		driver.findElement(By.name("username")).sendKeys("3341");
		driver.findElement(By.name("password")).sendKeys("Mahes");
		
		
		driver.findElement(By.name("signon")).click();
		driver.close();

}
}