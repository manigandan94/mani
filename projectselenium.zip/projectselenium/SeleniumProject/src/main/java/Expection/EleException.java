package Expection;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class EleException {
	    static WebDriver driver;
	    public static void screenshot(String s)
	    {
	        //IO Exception
	        try {
	        TakesScreenshot s1 =((TakesScreenshot)driver);
	        File source=s1.getScreenshotAs(OutputType.FILE);
	        File target = new File("");
	        FileUtils.copyFile(source, target);
	        } catch (IOException e) 
	        {
	            System.out.println("Path not found I/O exception");
	        }    
	    }
	    public static void main(String[] args) throws Exception
	    {
	          
	         driver = new ChromeDriver();
	         driver.manage().window().maximize();
	         driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	         driver.get("https://opensource-demo.orangehrmlive.com/");
	         WebElement s2=driver.findElement(By.id("txtUsername"));
	         s2.sendKeys("Admin");
	        WebElement s3= driver.findElement(By.id("txtPassword"));
	        		s3.sendKeys("admin123");
	         //No Such Element Exception
	         try 
	         {
	            driver.findElement(By.id("12345678")).click();
	        } 
	         catch (Exception e) 
	        {
	            System.out.println("No Such Element Exception");
	            
	        }
	         //No Alert Present Exception
	         try 
	         {
	            Alert alert = driver.switchTo().alert();
	            alert.accept();
	        } 
	         catch (Exception e) 
	        {
	            System.out.println("No Alert Present Exception");
	            
	        }
	         //No Such Frame Exception
	         try {
	            driver.switchTo().frame("a077aa5e");
	        } catch (Exception e) {
	            
	            System.out.println("No Such Frame Exception");
	        }
	         screenshot("welcome");
	         driver.findElement(By.id("btnLogin")).click();
	         
	         driver.findElement(By.id("welcome")).click();
	         
	         driver.findElement(By.xpath("//a[text()='Logout']")).click();
	         driver.close();
	         
	    }


	}

